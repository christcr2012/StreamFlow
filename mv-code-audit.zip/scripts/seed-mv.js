// scripts/seed-mv.js
/* Seed Mountain Vista baseline: Org + Owner + Provider (you) */
const { PrismaClient, Role } = require("@prisma/client");
const prisma = new PrismaClient();

async function main() {
  const ORG_NAME = process.env.SEED_ORG_NAME || "Mountain Vista Cleaning Services, LLC";
  const OWNER_EMAIL = (process.env.SEED_OWNER_EMAIL || "").toLowerCase().trim();
  const PROVIDER_EMAIL = (process.env.SEED_PROVIDER_EMAIL || "").toLowerCase().trim();

  if (!OWNER_EMAIL) throw new Error("SEED_OWNER_EMAIL is required");
  if (!PROVIDER_EMAIL) throw new Error("SEED_PROVIDER_EMAIL is required");

  // 1) Org
  let org = await prisma.org.findFirst({ where: { name: ORG_NAME } });
  if (!org) {
    org = await prisma.org.create({
      data: { name: ORG_NAME, featureFlags: {} },
    });
    console.log("Created org:", org.name, org.id);
  } else {
    console.log("Org exists:", org.name, org.id);
  }

  // 2) Owner (your client)
  const owner = await prisma.user.upsert({
    where: { email: OWNER_EMAIL },
    create: { email: OWNER_EMAIL, orgId: org.id, role: Role.OWNER, status: "active" },
    update: { orgId: org.id, role: Role.OWNER, status: "active" },
  });
  console.log("Owner user ensured:", owner.email, owner.role);

  // 3) Provider/Developer (you)
  const provider = await prisma.user.upsert({
    where: { email: PROVIDER_EMAIL },
    create: { email: PROVIDER_EMAIL, orgId: org.id, role: Role.PROVIDER, status: "active" },
    update: { orgId: org.id, role: Role.PROVIDER, status: "active" },
  });
  console.log("Provider user ensured:", provider.email, provider.role);

  // (Optional) add a tiny sanity lead so the app isn’t empty
  const leadCount = await prisma.lead.count({ where: { orgId: org.id } });
  if (leadCount === 0) {
    await prisma.lead.create({
      data: {
        orgId: org.id,
        publicId: `LEAD_${Math.random().toString(36).slice(2, 8).toUpperCase()}`,
        sourceType: "MANUAL_NEW_CUSTOMER",
        identityHash: "seed_identity_hash_1",
        company: "Seed Co",
        contactName: "Alex Example",
        email: "alex@example.com",
        phoneE164: "+15555550123",
        serviceCode: "janitorial",
        zip: "80631",
        aiScore: 55,
        scoreFactors: { reasons: ["Seed data"] },
        status: "new",
      },
    });
    console.log("Inserted 1 seed lead");
  }
}

main()
  .then(async () => {
    await prisma.$disconnect();
    console.log("Seed complete.");
  })
  .catch(async (e) => {
    console.error(e);
    await prisma.$disconnect();
    process.exit(1);
  });
