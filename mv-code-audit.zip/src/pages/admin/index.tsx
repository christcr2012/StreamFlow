// src/pages/admin/index.tsx
import { useMemo, useState } from "react";
import useSWR from "swr";
import type { GetServerSideProps } from "next";
import { getIronSession } from "iron-session";
import { sessionOptions, type SessionData } from "@/lib/session";
import { Role } from "@prisma/client";

type LeadRow = {
  id: string;
  createdAt: string;
  contactName: string | null;
  phoneE164: string | null;
  email: string | null;
  serviceCode: string | null;
  zip: string | null;
  source: string | null;
  score: number | null;
  status: string | null;
  notes: string | null;
};

type AdminLeadsResponse = { leads: LeadRow[] };

const fetcher = (url: string) => fetch(url).then((r) => r.json());

function fmt(d: Date) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export default function Admin() {
  const { data, error } = useSWR<AdminLeadsResponse>("/api/admin/leads", fetcher, {
    refreshInterval: 5000,
  });

  // ----- Date range state -----
  const today = useMemo(() => new Date(), []);
  const d7ago = useMemo(() => new Date(Date.now() - 7 * 24 * 3600 * 1000), []);
  const [start, setStart] = useState<string>(fmt(d7ago));
  const [end, setEnd] = useState<string>(fmt(today));

  const csvUrl = useMemo(() => {
    const qs = new URLSearchParams();
    if (start) qs.set("start", start);
    if (end) qs.set("end", end);
    return `/api/admin/export.csv?${qs.toString()}`;
  }, [start, end]);

  const jsonUrl = useMemo(() => {
    const qs = new URLSearchParams();
    if (start) qs.set("start", start);
    if (end) qs.set("end", end);
    return `/api/admin/export.json?${qs.toString()}`;
  }, [start, end]);

  function setPreset(days: number) {
    const now = new Date();
    const from = new Date(Date.now() - days * 24 * 3600 * 1000);
    setStart(fmt(from));
    setEnd(fmt(now));
  }

  if (error) {
    return (
      <main className="min-h-screen bg-gray-50">
        <div className="max-w-6xl mx-auto p-6">
          <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-red-700">
            Error loading admin data. Please refresh.
          </div>
        </div>
      </main>
    );
  }
  if (!data) {
    return (
      <main className="min-h-screen bg-gray-50">
        <div className="max-w-6xl mx-auto p-6">
          <div className="rounded-xl border border-gray-200 bg-white p-4 text-gray-600">
            Loading…
          </div>
        </div>
      </main>
    );
  }

  const leads = data.leads ?? [];

  return (
    <main className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto p-6 space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-semibold text-gray-900">Admin Console</h1>
            <p className="text-sm text-gray-500">Leads overview and exports</p>
          </div>

          {/* Controls */}
          <div className="flex flex-wrap items-end gap-2">
            <div className="flex items-center gap-2">
              <label className="text-xs text-gray-600">Start</label>
              <input
                type="date"
                value={start}
                onChange={(e) => setStart(e.target.value)}
                className="h-9 rounded-lg border border-gray-300 bg-white px-3 text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-black/10"
              />
            </div>
            <div className="flex items-center gap-2">
              <label className="text-xs text-gray-600">End</label>
              <input
                type="date"
                value={end}
                onChange={(e) => setEnd(e.target.value)}
                className="h-9 rounded-lg border border-gray-300 bg-white px-3 text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-black/10"
              />
            </div>

            <div className="hidden sm:block w-px h-6 bg-gray-200 mx-1" />

            <button
              onClick={() => setPreset(7)}
              className="h-9 rounded-lg border border-gray-300 bg-white px-3 text-sm hover:bg-gray-100"
            >
              Last 7d
            </button>
            <button
              onClick={() => setPreset(30)}
              className="h-9 rounded-lg border border-gray-300 bg-white px-3 text-sm hover:bg-gray-100"
            >
              30d
            </button>
            <button
              onClick={() => setPreset(90)}
              className="h-9 rounded-lg border border-gray-300 bg-white px-3 text-sm hover:bg-gray-100"
            >
              90d
            </button>

            <div className="hidden sm:block w-px h-6 bg-gray-200 mx-1" />

            <a
              href={csvUrl}
              className="h-9 inline-flex items-center rounded-lg border border-gray-300 bg-white px-3 text-sm hover:bg-gray-100"
            >
              Export CSV
            </a>
            <a
              href={jsonUrl}
              className="h-9 inline-flex items-center rounded-lg border border-gray-300 bg-white px-3 text-sm hover:bg-gray-100"
            >
              Export JSON
            </a>
          </div>
        </div>

        {/* Table Card */}
        <div className="rounded-xl border border-gray-200 bg-white shadow-sm">
          <div className="overflow-x-auto">
            <table className="min-w-[1000px] w-full text-sm">
              <thead className="bg-gray-50 sticky top-0">
                <tr className="text-left text-gray-600">
                  <th className="py-3 px-4 font-medium">Created</th>
                  <th className="py-3 px-4 font-medium">ID</th>
                  <th className="py-3 px-4 font-medium">Contact</th>
                  <th className="py-3 px-4 font-medium">Phone</th>
                  <th className="py-3 px-4 font-medium">Email</th>
                  <th className="py-3 px-4 font-medium">Service</th>
                  <th className="py-3 px-4 font-medium">ZIP</th>
                  <th className="py-3 px-4 font-medium">Source</th>
                  <th className="py-3 px-4 font-medium">Score</th>
                  <th className="py-3 px-4 font-medium">Status</th>
                  <th className="py-3 px-4 font-medium">Notes</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {leads.map((l) => (
                  <tr key={l.id} className="hover:bg-gray-50">
                    <td className="py-3 px-4 text-gray-700">{new Date(l.createdAt).toLocaleString()}</td>
                    <td className="py-3 px-4">
                      <code className="text-xs bg-gray-100 rounded px-1 py-0.5">{l.id}</code>
                    </td>
                    <td className="py-3 px-4 text-gray-800">{l.contactName || "—"}</td>
                    <td className="py-3 px-4 text-gray-700">{l.phoneE164 || "—"}</td>
                    <td className="py-3 px-4 text-gray-700">{l.email || "—"}</td>
                    <td className="py-3 px-4">
                      <span className="inline-flex items-center rounded-full bg-blue-50 text-blue-700 px-2 py-0.5 text-xs border border-blue-200">
                        {l.serviceCode || "—"}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-gray-700">{l.zip || "—"}</td>
                    <td className="py-3 px-4 text-gray-700">{l.source || "—"}</td>
                    <td className="py-3 px-4 text-gray-800">{typeof l.score === "number" ? l.score : "—"}</td>
                    <td className="py-3 px-4">
                      <span className="inline-flex items-center rounded-full bg-emerald-50 text-emerald-700 px-2 py-0.5 text-xs border border-emerald-200">
                        {l.status || "—"}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-gray-700 whitespace-pre-wrap max-w-[28rem]">
                      {l.notes || "—"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Footer */}
          <div className="flex items-center justify-between px-4 py-3 text-xs text-gray-500">
            <span> Total: {leads.length.toLocaleString()} lead{leads.length === 1 ? "" : "s"} </span>
            <span>Auto-refreshing every 5s</span>
          </div>
        </div>
      </div>
    </main>
  );
}

// ----- SERVER-SIDE GUARD (single export) -----
export const getServerSideProps: GetServerSideProps = async ({ req, res }) => {
  // @ts-ignore – Next provides Node req/res
  const session = await getIronSession<SessionData>(req, res, sessionOptions);
  const u = session.user;
  if (!u) {
    return { redirect: { destination: "/login", permanent: false } };
  }
  if (u.role !== Role.OWNER && u.role !== Role.STAFF) {   // ✅ enum checks
    return { redirect: { destination: "/leads", permanent: false } };
  }
  return { props: {} };
};
