import { useState } from 'react';

type LeadInput = {
  contact: { name: string; phone?: string; email?: string };
  service: string;
  zip?: string;
  notes?: string;
  source?: string;
};

export default function Intake() {
  const [loading, setLoading] = useState(false);
  const [ok, setOk] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setOk(null);
    setErr(null);
    setLoading(true);

    const form = e.currentTarget as any;
    const payload: LeadInput = {
      contact: {
        name: form.name.value.trim(),
        phone: form.phone.value.trim() || undefined,
        email: form.email.value.trim() || undefined,
      },
      service: form.service.value.trim(),
      zip: form.zip.value.trim() || undefined,
      notes: form.notes.value.trim() || undefined,
      source: 'web_form',
    };

    // simple client validation
    if (!payload.contact.name) {
      setLoading(false);
      setErr('Please enter a name.');
      return;
    }
    if (!payload.service) {
      setLoading(false);
      setErr('Please enter a service or reason for contacting.');
      return;
    }

    try {
      const res = await fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const j = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(j?.error || 'Failed to submit lead.');
      setOk('Thanks! Your request has been received.');
      form.reset();
    } catch (e: any) {
      setErr(e?.message || 'Something went wrong while submitting your request.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-gray-50">
      <div className="max-w-xl mx-auto p-6 space-y-6">
        {/* Header */}
        <header>
          <h1 className="text-2xl font-semibold text-gray-900">Request Service</h1>
          <p className="text-sm text-gray-500">Tell us what you need and how to reach you.</p>
        </header>

        {/* Alerts */}
        {ok && (
          <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-emerald-800">
            {ok}
          </div>
        )}
        {err && (
          <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-red-800">
            {err}
          </div>
        )}

        {/* Form */}
        <form onSubmit={submit} className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm space-y-4">
          <div className="space-y-1.5">
            <label htmlFor="name" className="text-sm font-medium text-gray-700">Your name *</label>
            <input
              id="name"
              name="name"
              required
              placeholder="Jane Doe"
              className="h-11 w-full rounded-lg border border-gray-300 bg-white px-3 text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-black/10"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label htmlFor="phone" className="text-sm font-medium text-gray-700">Phone</label>
              <input
                id="phone"
                name="phone"
                inputMode="tel"
                placeholder="(555) 555-1234"
                className="h-11 w-full rounded-lg border border-gray-300 bg-white px-3 text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-black/10"
              />
              <p className="text-xs text-gray-500">Optional — we’ll only use it for scheduling/updates.</p>
            </div>
            <div className="space-y-1.5">
              <label htmlFor="email" className="text-sm font-medium text-gray-700">Email</label>
              <input
                id="email"
                name="email"
                inputMode="email"
                placeholder="jane@example.com"
                className="h-11 w-full rounded-lg border border-gray-300 bg-white px-3 text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-black/10"
              />
              <p className="text-xs text-gray-500">Optional — one of phone or email helps us reply.</p>
            </div>
          </div>

          <div className="space-y-1.5">
            <label htmlFor="service" className="text-sm font-medium text-gray-700">What do you need? *</label>
            <input
              id="service"
              name="service"
              required
              placeholder="e.g., Move-out deep clean, Weekly office cleaning, etc."
              className="h-11 w-full rounded-lg border border-gray-300 bg-white px-3 text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-black/10"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label htmlFor="zip" className="text-sm font-medium text-gray-700">ZIP code</label>
              <input
                id="zip"
                name="zip"
                inputMode="numeric"
                placeholder="12345"
                className="h-11 w-full rounded-lg border border-gray-300 bg-white px-3 text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-black/10"
              />
            </div>
            <div className="space-y-1.5">
              <label htmlFor="notes" className="text-sm font-medium text-gray-700">Notes</label>
              <input
                id="notes"
                name="notes"
                placeholder="Any special details or timing?"
                className="h-11 w-full rounded-lg border border-gray-300 bg-white px-3 text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-black/10"
              />
            </div>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              disabled={loading}
              className="h-11 w-full sm:w-auto rounded-lg bg-black px-5 text-white text-sm font-medium hover:bg-gray-900 disabled:opacity-60"
            >
              {loading ? 'Submitting…' : 'Submit Request'}
            </button>
          </div>

          <p className="text-xs text-gray-500">
            By submitting, you agree we may contact you about this request.
          </p>
        </form>

        {/* Back link */}
        <div className="text-sm">
          <a href="/" className="text-gray-600 hover:underline">← Back to home</a>
        </div>
      </div>
    </main>
  );
}
