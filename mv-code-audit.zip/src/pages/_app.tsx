import type { AppProps } from 'next/app'
import Head from 'next/head'
import '../styles/globals.css'
import Header from '../components/Header'

export default function MyApp({ Component, pageProps }: AppProps) {
  return (
    <>
      <Head>
        <link rel="icon" href="/favicon.png" />
        {/* fallback: some browsers still prefer .ico */}
        <link rel="icon" href="/favicon.ico" />
        <title>Mountain Vista</title>
      </Head>
      <Header />
      <Component {...pageProps} />
    </>
  )
}
