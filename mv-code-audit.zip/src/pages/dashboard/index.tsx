// src/pages/dashboard/index.tsx
import { useEffect, useState } from "react";
import { GetServerSideProps } from "next";
import { getIronSession } from "iron-session";
import { sessionOptions, type SessionData } from "@/lib/session";
import { Role } from "@prisma/client";

type Summary = {
  kpis: {
    totalLeads: number;
    leadsThisWeek: number;
    hotLeads: number;
    rfpLeads: number;
    totalConversions: number;
    conversionsThisWeek: number;
    lifetimePackPurchasesUSD: number;
    weekStartISO: string;
  };
  recentLeads: Array<{
    id: string;
    publicId: string;
    sourceType: "COLD" | "HOT" | "RFP";
    company: string | null;
    serviceCode: string | null;
    zip: string | null;
    aiScore: number | null;
    createdAt: string;
    scoreFactors?: { reasons?: string[] } | null;
 }>;
  recentPurchases: Array<{
    id: string;
    amount: number | string;
    createdAt: string;
    meta?: any;
  }>;
};

async function startPackCheckout(quantity = 1, unitAmountCents = 1000) {
  const res = await fetch("/api/packs/purchase", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ quantity, unitAmount: unitAmountCents }),
  });
  const data = await res.json();
  if (!res.ok || !data?.url) throw new Error(data?.error || "Checkout failed");
  window.location.href = data.url;
}

export default function Dashboard() {
  const [data, setData] = useState<Summary | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/dashboard/summary");
      const json = await res.json();
      if (!res.ok) throw new Error(json?.error || "Failed to load dashboard");
      setData(json);
    } catch (e: any) {
      setError(e?.message || "Failed to load");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);
  const k = data?.kpis;

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur border-b">
  <div className="mx-auto max-w-6xl px-4 py-4 flex items-center justify-between">
    <h1 className="text-2xl font-semibold">Dashboard</h1>
    <nav className="flex gap-3 text-sm items-center">
      <a className="text-blue-600 hover:underline" href="/leads">Leads</a>
      <a className="text-blue-600 hover:underline" href="/">Home</a>
      <button
        onClick={async () => {
          try {
            await fetch("/api/auth/logout", { method: "POST" });
          } catch {}
          window.location.href = "/login";
        }}
        className="ml-3 rounded-md border px-3 py-1 hover:bg-gray-50"
      >
        Sign out
      </button>
    </nav>
  </div>
</header>

      <main className="mx-auto max-w-6xl p-4 grid gap-6">
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {loading ? (
            <div className="text-sm text-gray-600">Loading…</div>
          ) : error ? (
            <div className="rounded-md border bg-rose-50 text-rose-900 px-3 py-2">{error}</div>
          ) : k ? (
            <>
              <Card title="Leads (Total)" value={k.totalLeads} />
              <Card title={`Leads (Since ${new Date(k.weekStartISO).toLocaleDateString()})`} value={k.leadsThisWeek} />
              <Card title="Hot Leads" value={k.hotLeads} />
              <Card title="RFP Leads" value={k.rfpLeads} />
              <Card title="Conversions (Total)" value={k.totalConversions} />
              <Card title="Conversions (This Week)" value={k.conversionsThisWeek} />
              <Card title="Packs Purchased (Lifetime $)" value={`$${k.lifetimePackPurchasesUSD.toFixed(2)}`} />
            </>
          ) : null}
        </section>

        <section className="bg-white rounded-xl shadow-sm border p-4">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-medium">Buy Lead Pack</h2>
          </div>
          <div className="flex flex-wrap gap-3 items-center">
            <button onClick={() => startPackCheckout(1, 1000)} className="rounded-md bg-blue-600 text-white px-4 py-2 font-medium hover:bg-blue-700">
              Buy 1 pack ($10)
            </button>
            <button onClick={() => startPackCheckout(5, 1000)} className="rounded-md border px-4 py-2 hover:bg-gray-50">
              Buy 5 packs ($50)
            </button>
            <button onClick={() => startPackCheckout(10, 1000)} className="rounded-md border px-4 py-2 hover:bg-gray-50">
              Buy 10 packs ($100)
            </button>
          </div>
          <p className="mt-3 text-sm text-gray-600">
            Uses Stripe Checkout in test mode. Prices are placeholders—edit <code>unitAmount</code> in the handlers above.
          </p>
        </section>

        <section className="bg-white rounded-xl shadow-sm border p-4">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-medium">Recent Leads</h2>
            <button onClick={load} className="text-sm rounded-md border px-3 py-1 hover:bg-gray-50">Refresh</button>
          </div>
          {loading ? (
            <div className="text-sm text-gray-600">Loading…</div>
          ) : !data || data.recentLeads.length === 0 ? (
            <div className="text-sm text-gray-600">No recent leads.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm">
                <thead className="text-left bg-gray-100">
                  <tr>
                    <th className="p-2">Public ID</th>
                    <th className="p-2">Source</th>
                    <th className="p-2">Company</th>
                    <th className="p-2">Service</th>
                    <th className="p-2">ZIP</th>
                    <th className="p-2">Score</th>
                    <th className="p-2">Reasons</th>
                    <th className="p-2">Created</th>
                  </tr>
                </thead>
                <tbody>
                  {data.recentLeads.map((l) => (
                    <tr key={l.id} className="border-t">
                      <td className="p-2 font-mono">{l.publicId}</td>
                      <td className="p-2">{l.sourceType}</td>
                      <td className="p-2">{l.company || "—"}</td>
                      <td className="p-2">{l.serviceCode || "—"}</td>
                      <td className="p-2">{l.zip || "—"}</td>
                      <td className="p-2">{l.aiScore ?? "—"}</td>
                      <td className="p-2">
        {Array.isArray(l.scoreFactors?.reasons) && l.scoreFactors!.reasons!.length > 0
          ? l.scoreFactors!.reasons!.join(", ")
          : "—"}
      </td>
                      <td className="p-2">{new Date(l.createdAt).toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>

        <section className="bg-white rounded-xl shadow-sm border p-4">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-medium">Recent Purchases</h2>
            <span className="text-sm text-gray-500">
              Lifetime: ${data?.kpis.lifetimePackPurchasesUSD.toFixed(2)}
            </span>
          </div>
          {!data || (data.recentPurchases || []).length === 0 ? (
            <div className="text-sm text-gray-600">No purchases yet.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm">
                <thead className="text-left bg-gray-100">
                  <tr>
                    <th className="p-2">Date</th>
                    <th className="p-2">Amount</th>
                    <th className="p-2">Session</th>
                  </tr>
                </thead>
                <tbody>
                  {data.recentPurchases.map((p) => (
                    <tr key={p.id} className="border-t">
                      <td className="p-2">{new Date(p.createdAt).toLocaleString()}</td>
                      <td className="p-2">${Number(p.amount).toFixed(2)}</td>
                      <td className="p-2">
                        {p.meta?.sessionId ? <code className="text-xs">{p.meta.sessionId}</code> : "—"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </main>
    </div>
  );
}

function Card({ title, value }: { title: string; value: number | string }) {
  return (
    <div className="bg-white rounded-xl shadow-sm border p-4">
      <div className="text-sm text-gray-600">{title}</div>
      <div className="mt-1 text-2xl font-semibold">{value}</div>
    </div>
  );
}
export const getServerSideProps: GetServerSideProps = async ({ req, res }) => {
  // @ts-ignore – Next provides Node req/res
  const session = await getIronSession<SessionData>(req, res, sessionOptions);
  const u = session.user;
  if (!u) return { redirect: { destination: "/login", permanent: false } };
  if (u.role !== Role.OWNER && u.role !== Role.STAFF) {   // ✅ enum checks
    return { redirect: { destination: "/leads", permanent: false } };
  }
  return { props: {} };
};

