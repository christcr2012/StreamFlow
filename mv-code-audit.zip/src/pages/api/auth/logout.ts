// src/pages/api/auth/logout.ts
import type { NextApiRequest, NextApiResponse } from "next";
import { getIronSession } from "iron-session";
import { sessionOptions, type SessionData } from "@/lib/session";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).end("Method Not Allowed");
  }
  const session = await getIronSession<SessionData>(req, res, sessionOptions);
  await session.destroy(); // clears cookie + data
  return res.status(200).json({ ok: true });
}
