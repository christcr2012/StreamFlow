// src/pages/api/auth/login.ts
import type { NextApiRequest, NextApiResponse } from "next";
import { getIronSession } from "iron-session";
import { sessionOptions, type SessionData } from "@/lib/session";
import { prisma } from "@/lib/prisma";
import type { Role } from "@prisma/client";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Method Not Allowed" });
  }

  const rawEmail =
    (typeof req.body?.email === "string" && req.body.email) ||
    (typeof req.query?.email === "string" && req.query.email) ||
    "";
  const email = rawEmail.trim().toLowerCase();
  if (!email) return res.status(400).json({ error: "Email required" });

  try {
    const user = await prisma.user.findUnique({ where: { email } });
    if (!user) return res.status(401).json({ error: "Not allowlisted" });

    // Create session
    const session = await getIronSession<SessionData>(req, res, sessionOptions);
    session.user = { email: user.email, role: user.role as Role };
    await session.save();

    // Redirect rules:
    // - OWNER, MANAGER, STAFF -> dashboard
    // - PROVIDER, ACCOUNTANT  -> leads
    const r = user.role;
    const redirectTo =
      r === "OWNER" || r === "MANAGER" || r === "STAFF" ? "/dashboard" : "/leads";

    return res.status(200).json({ ok: true, user: session.user, redirectTo });
  } catch (err) {
    console.error("Login error:", err);
    return res.status(500).json({ error: "Server error" });
  }
}
