// src/pages/api/admin/export.csv.ts
import type { NextApiRequest, NextApiResponse } from "next";
import { getIronSession } from "iron-session";
import { sessionOptions, type SessionData } from "@/lib/session";
import { prisma } from "@/lib/prisma";

function toCsvValue(v: unknown) {
  if (v === null || v === undefined) return "";
  const s = String(v);
  const needsQuotes = /[",\n]/.test(s);
  const escaped = s.replace(/"/g, '""');
  return needsQuotes ? `"${escaped}"` : escaped;
}

// Supports ?range=d7|d30|d90|all OR ?start=YYYY-MM-DD&end=YYYY-MM-DD
function parseRange(q: NextApiRequest["query"]) {
  const { range, start, end } = q as Record<string, string | undefined>;
  let gte: Date | undefined;
  let lte: Date | undefined;

  if (start || end) {
    if (start) gte = new Date(start + "T00:00:00Z");
    if (end) lte = new Date(end + "T23:59:59Z");
    return { gte, lte };
  }

  const now = new Date();
  const days =
    range === "d7" ? 7 :
    range === "d30" ? 30 :
    range === "d90" ? 90 :
    undefined;

  if (days) gte = new Date(now.getTime() - days * 24 * 60 * 60 * 1000);
  return { gte, lte };
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // Bind session for this request
  // @ts-ignore - Next provides Node req/res here
  const session = await getIronSession<SessionData>(req, res, sessionOptions);
  const u = session.user;

  // AuthZ: only OWNER/STAFF
  if (!u) return res.status(401).json({ error: "Unauthorized" });
if (u.role !== "OWNER" && u.role !== "MANAGER" && u.role !== "STAFF") {
  return res.status(403).json({ error: "Forbidden" });
}

  if (req.method !== "GET") {
    res.setHeader("Allow", "GET");
    return res.status(405).end("Method Not Allowed");
  }

  const { gte, lte } = parseRange(req.query);
  const where: any = {};
  if (gte || lte) where.createdAt = { ...(gte ? { gte } : {}), ...(lte ? { lte } : {}) };

  const leads = await prisma.lead.findMany({
  where,
  orderBy: { createdAt: "desc" },
  take: 10000,
  select: {
    id: true,
    publicId: true,
    createdAt: true,
    company: true,
    contactName: true,
    email: true,
    phoneE164: true,
    serviceCode: true,
    addressLine1: true,
    addressLine2: true,
    city: true,
    state: true,
    notes: true,
    sourceDetail: true,
    zip: true,
    postalCode: true,
    sourceType: true,
    aiScore: true,
    status: true,
  },
});

  const headers = [
  "id",
  "publicId",
  "createdAt",
  "company",
  "contactName",
  "email",
  "phoneE164",
  "serviceCode",
  "addressLine1",
  "addressLine2",
  "city",
  "state",
  "notes",
  "sourceDetail",
  "zip",
  "postalCode",
  "sourceType",
  "aiScore",
  "status",
];
  const rows: string[] = [headers.join(",")];

  for (const l of leads) {
  rows.push(
    [
      toCsvValue(l.id),
      toCsvValue(l.publicId),
      toCsvValue(l.createdAt instanceof Date ? l.createdAt.toISOString() : String(l.createdAt)),
      toCsvValue(l.company ?? ""),
      toCsvValue(l.contactName ?? ""),
      toCsvValue(l.email ?? ""),
      toCsvValue(l.phoneE164 ?? ""),
      toCsvValue(l.serviceCode ?? ""),
      toCsvValue(l.addressLine1 ?? ""),
      toCsvValue(l.addressLine2 ?? ""),
      toCsvValue(l.city ?? ""),
      toCsvValue(l.state ?? ""),
      toCsvValue(l.notes ?? ""),
      toCsvValue(l.sourceDetail ?? ""),
      toCsvValue(l.zip ?? ""),
      toCsvValue(l.postalCode ?? ""),
      toCsvValue(l.sourceType ?? ""),
      toCsvValue(typeof l.aiScore === "number" ? l.aiScore : ""),
      toCsvValue(l.status ?? ""),
    ].join(",")
  );
}

  const ts = new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-");
  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", `attachment; filename="leads_export_${ts}.csv"`);
  return res.status(200).send(rows.join("\n"));
}
