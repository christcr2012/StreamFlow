// src/pages/api/admin/leads.ts
import type { NextApiRequest, NextApiResponse } from "next";
import { getIronSession } from "iron-session";
import { sessionOptions, type SessionData } from "@/lib/session";
import { prisma } from "@/lib/prisma";

// Gate with a helper that LOADS the session (no wrapper needed)
async function requireAdmin(
  req: NextApiRequest,
  res: NextApiResponse
): Promise<{ ok: true } | { ok: false }> {
  const session = await getIronSession<SessionData>(req, res, sessionOptions);
  const u = session.user;
  if (!u) {
    res.status(401).json({ error: "Unauthorized" });
    return { ok: false };
  }
  if (u.role !== "OWNER" && u.role !== "MANAGER" && u.role !== "STAFF") {
    res.status(403).json({ error: "Forbidden" });
    return { ok: false };
  }
  return { ok: true };
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const gate = await requireAdmin(req, res);
  if (!gate.ok) return;

  switch (req.method) {
    case "GET": {
      const leads = await prisma.lead.findMany({
        orderBy: { createdAt: "desc" },
        take: 100,
      });
      return res.status(200).json({ leads });
    }
    default: {
      res.setHeader("Allow", "GET");
      return res.status(405).end("Method Not Allowed");
    }
  }
}
