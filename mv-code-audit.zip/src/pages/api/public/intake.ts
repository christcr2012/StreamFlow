import type { NextApiRequest, NextApiResponse } from "next";
import { prisma } from "@/lib/prisma";
import { z } from "zod";

// ---- Config ----
const SECRET = process.env.PUBLIC_INTAKE_SHARED_SECRET || "";
const ALLOWED = (process.env.PUBLIC_ALLOWED_ORIGINS || "")
  .split(",")
  .map(s => s.trim())
  .filter(Boolean);

// Basic CORS for server-to-server (preflight optional)
function setCors(res: NextApiResponse, origin?: string) {
  if (origin && ALLOWED.includes(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Vary", "Origin");
  }
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, X-INTAKE-KEY");
}

// Minimal request throttle (in-memory)
const ipHits = new Map<string, { count: number; ts: number }>();
function tooMany(req: NextApiRequest, maxPerMin = 60) {
  const ip = (req.headers["x-forwarded-for"] as string)?.split(",")[0]?.trim() || req.socket.remoteAddress || "unknown";
  const now = Date.now();
  const entry = ipHits.get(ip) || { count: 0, ts: now };
  if (now - entry.ts > 60_000) {
    ipHits.set(ip, { count: 1, ts: now });
    return false;
  }
  entry.count += 1;
  ipHits.set(ip, entry);
  return entry.count > maxPerMin;
}

// Validate payload
const IntakeSchema = z.object({
  company: z.string().min(1),
  contactName: z.string().min(1),
  email: z.string().email().optional().nullable(),
  phone: z.string().optional().nullable(),
  serviceCode: z.string().min(1),
  zip: z.string().min(3).max(10),
  website: z.string().url().optional().nullable()
});

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  setCors(res, req.headers.origin as string | undefined);

  if (req.method === "OPTIONS") {
    return res.status(204).end();
  }
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST, OPTIONS");
    return res.status(405).json({ error: "Method Not Allowed" });
  }

  // Rate limit
  if (tooMany(req)) return res.status(429).json({ error: "Too many requests" });

  // Shared secret (sent by the public site's server-side proxy)
  const key = (req.headers["x-intake-key"] as string) || "";
  if (!SECRET || key !== SECRET) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  // Validate JSON
  let payload: z.infer<typeof IntakeSchema>;
  try {
    payload = IntakeSchema.parse(req.body);
  } catch (e: any) {
    return res.status(400).json({ error: "Invalid input", details: e?.errors });
  }

  // Create the Lead (adjust fields to your schema)
  const lead = await prisma.lead.create({
    data: {
      orgId: process.env.SEED_ORG_ID || "", // or decide org assignment logic
      publicId: `LEAD_${Math.random().toString(36).slice(2, 8).toUpperCase()}`,
      sourceType: "COLD",                         // or "RFP"/"HOT" if known
      identityHash: "",                         // optional hashing strategy later
      company: payload.company,
      contactName: payload.contactName,
      email: payload.email ?? null,
      phoneE164: payload.phone ?? null,
      website: payload.website ?? null,
      serviceCode: payload.serviceCode,
      zip: payload.zip,
      enrichmentJson: {},
      aiScore: 0,
      scoreFactors: {},
      status: "new",
    },
    select: { id: true, publicId: true, createdAt: true }
  });

  return res.status(201).json({ ok: true, lead });
}
