// src/pages/api/dashboard/summary.ts
import type { NextApiRequest, NextApiResponse } from "next";
import { prisma } from "@/lib/prisma";

// Helper: start of current week (Sun 00:00)
function startOfWeek(d = new Date()) {
  const copy = new Date(d);
  copy.setHours(0, 0, 0, 0);
  const day = copy.getDay(); // 0 = Sun
  copy.setDate(copy.getDate() - day);
  return copy;
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  try {
    // MVP: use first org
    const org = await prisma.org.findFirst();
    if (!org) return res.status(400).json({ error: "Org not seeded" });

    const weekStart = startOfWeek();

    // Leads
    const [totalLeads, weekLeads, hotLeads, rfpLeads] = await Promise.all([
      prisma.lead.count({ where: { orgId: org.id } }),
      prisma.lead.count({ where: { orgId: org.id, createdAt: { gte: weekStart } } }),
      prisma.lead.count({ where: { orgId: org.id, sourceType: "HOT" } }),
      prisma.lead.count({ where: { orgId: org.id, sourceType: "RFP" } }),
    ]);

    // Simple recent leads list (last 10)
    const recentLeads = await prisma.lead.findMany({
  where: { orgId: org.id },
  orderBy: { createdAt: "desc" },
  take: 10,
  select: {
    id: true,
    publicId: true,
    sourceType: true,
    company: true,
    serviceCode: true,
    zip: true,
    aiScore: true,
    createdAt: true,
    scoreFactors: true, // ← add this line
  },
});

    // Opportunities (treat as "conversions" for now)
    const [totalOpps, weekOpps] = await Promise.all([
      prisma.opportunity.count({ where: { orgId: org.id } }),
      prisma.opportunity.count({ where: { orgId: org.id, createdAt: { gte: weekStart } } }),
    ]);

    // Billing ledger — lifetime purchased packs ($ via PACK_PURCHASE)
    const packSum = await prisma.billingLedger.aggregate({
      where: { orgId: org.id, type: "PACK_PURCHASE" },
      _sum: { amount: true },
    });

    // Recent purchases (last 5)
    const recentPurchases = await prisma.billingLedger.findMany({
      where: { orgId: org.id, type: "PACK_PURCHASE" },
      orderBy: { createdAt: "desc" },
      take: 5,
      select: { id: true, amount: true, createdAt: true, meta: true },
    });

    return res.json({
      kpis: {
        totalLeads,
        leadsThisWeek: weekLeads,
        hotLeads,
        rfpLeads,
        totalConversions: totalOpps,
        conversionsThisWeek: weekOpps,
        lifetimePackPurchasesUSD: Number(packSum._sum.amount ?? 0),
        weekStartISO: weekStart.toISOString(),
      },
      recentLeads,
      recentPurchases,
    });
  } catch (e: any) {
    console.error(e);
    res.status(500).json({ error: e?.message || "Server error" });
  }
}
