// pages/api/_echo.ts
import type { NextApiRequest, NextApiResponse } from "next";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  try {
    if (req.method === "POST") {
      // If body is a string (some clients send raw), try to parse it
      const body = typeof req.body === "string" ? JSON.parse(req.body || "{}") : (req.body ?? {});
      return res.status(200).json({ ok: true, router: "pages", method: "POST", body, now: new Date().toISOString() });
    }
    // GET (or anything else) returns a simple JSON
    return res.status(200).json({ ok: true, router: "pages", method: req.method, now: new Date().toISOString() });
  } catch (err: any) {
    return res.status(400).json({ ok: false, error: String(err?.message || err) });
  }
}
