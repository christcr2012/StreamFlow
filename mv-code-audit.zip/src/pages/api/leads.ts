// src/pages/api/leads.ts
import type { NextApiRequest, NextApiResponse } from "next";
import { prisma } from "@/lib/prisma";
import { LeadSource } from "@prisma/client";
import crypto from "node:crypto";

/** Pages Router default is Node runtime; ensure we use the Node body parser */
export const config = {
  api: {
    bodyParser: {
      sizeLimit: "1mb",
    },
  },
};

function normalize(s?: string | null) {
  return (s ?? "").trim().toLowerCase();
}

function identityHash(input: {
  email?: string | null;
  phoneE164?: string | null;
  company?: string | null;
  name?: string | null;
}) {
  const key = [
    normalize(input.email),
    normalize(input.phoneE164),
    normalize(input.company),
    normalize(input.name),
  ]
    .filter(Boolean)
    .join("|");
  return crypto.createHash("sha256").update(key).digest("hex").slice(0, 24);
}

/** Accepts old/new/manual UI values and maps to our Prisma enum safely */
function mapSourceType(raw?: string | null): LeadSource {
  const v = (raw ?? "").toUpperCase();

  if (v === "COLD") return LeadSource.COLD;
  if (v === "HOT") return LeadSource.HOT;
  if (v === "RFP") return LeadSource.RFP;

  if (v === "MANUAL_EMPLOYEE_REFERRAL" || v === "EMPLOYEE_REFERRAL")
    return LeadSource.MANUAL_EMPLOYEE_REFERRAL;
  if (v === "MANUAL_EXISTING_CUSTOMER" || v === "EXISTING_CUSTOMER")
    return LeadSource.MANUAL_EXISTING_CUSTOMER;
  if (v === "MANUAL_NEW_CUSTOMER" || v === "NEW_CUSTOMER")
    return LeadSource.MANUAL_NEW_CUSTOMER;

  if (v === "MANUAL_OTHER" || v === "OTHER")
    return LeadSource.MANUAL_OTHER;

  return LeadSource.MANUAL_OTHER;
}

/** Safe body parsing that never throws on empty string or non-JSON */
function safeParseBody(req: NextApiRequest): Record<string, any> {
  const ct = (req.headers["content-type"] || "").toString();
  const raw = req.body;

  // Next Pages API usually parses JSON into object already unless disabled.
  if (raw && typeof raw === "object") return raw as Record<string, any>;

  if (typeof raw === "string") {
    const s = raw.trim();
    if (!s) return {}; // empty string → empty object
    try {
      return JSON.parse(s);
    } catch {
      // If the client lied about JSON, we fail gracefully (handled above in POST)
      return { __invalidJson: true, __raw: s };
    }
  }

  // If no body or unknown type, just return empty object
  return {};
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  res.setHeader("Content-Type", "application/json; charset=utf-8");

  try {
    if (req.method === "GET") {
      const leads = await prisma.lead.findMany({
        orderBy: { createdAt: "desc" },
        take: 100,
        select: {
          id: true,
          publicId: true,
          sourceType: true,
          company: true,
          contactName: true,
          email: true,
          phoneE164: true,
          serviceCode: true,
          zip: true,
          postalCode: true,
          aiScore: true,
          scoreFactors: true,
          status: true,
          createdAt: true,
        },
      });
      return res.status(200).json({ ok: true, leads });
    }

    if (req.method === "POST") {
      const body = safeParseBody(req);
      if ((body as any).__invalidJson) {
        return res.status(400).json({ ok: false, error: "Invalid JSON in request body" });
      }

      // MVP assumption: single org present from seed
      const org = await prisma.org.findFirst();
      if (!org) {
        return res.status(400).json({ ok: false, error: "Org not seeded. Run seed script." });
      }

      // Compute identity hash to detect duplicates
      const hash = identityHash({
        email: body.email,
        phoneE164: body.phoneE164,
        company: body.company,
        name: body.contactName,
      });

      const dup = await prisma.lead.findFirst({
        where: { orgId: org.id, identityHash: hash },
        select: { id: true, publicId: true, createdAt: true },
      });
      if (dup) {
        return res
          .status(200)
          .json({ ok: true, duplicate: true, reason: "Identity hash matched", lead: dup });
      }

      const sourceType: LeadSource = mapSourceType(body.sourceType);

      // Basic scoring
      const reasons: string[] = [];
      let score = 50;
      if (body.serviceCode) {
        score += 5;
        reasons.push("Matched service category");
      }
      if (body.postalCode || body.zip) {
        score += 5;
        reasons.push("Provided postal/ZIP");
      }
      if (score > 100) score = 100;

      const created = await prisma.lead.create({
        data: {
          orgId: org.id,
          publicId: `LEAD_${Math.random().toString(36).slice(2, 8).toUpperCase()}`,
          sourceType,
          identityHash: hash,

          company: body.company ?? null,
          contactName: body.contactName ?? null,
          email: body.email ?? null,
          phoneE164: body.phoneE164 ?? null,
          website: body.website ?? null,
          serviceCode: body.serviceCode ?? null,

          // Address
          address:
            body.addressLine1
              ? `${body.addressLine1}${body.addressLine2 ? ", " + body.addressLine2 : ""}`
              : body.address ?? null,
          addressLine1: body.addressLine1 ?? null,
          addressLine2: body.addressLine2 ?? null,
          city: body.city ?? null,
          state: body.state ?? null,
          postalCode: body.postalCode ?? null,
          zip: body.zip ?? body.postalCode ?? null,
          country: body.country ?? null,

          // Enrichment + scoring
          enrichmentJson: {},
          aiScore: score,
          scoreFactors: {
            reasons,
            sourceDetail: body.sourceDetail ?? null,
            notes: body.notes ?? null,
          } as any,

          notes: body.notes ?? null,
          // status: leave to schema default; if enum, setting a string could throw
        },
        select: {
          id: true,
          publicId: true,
          sourceType: true,
          aiScore: true,
          createdAt: true,
        },
      });

      return res.status(201).json({ ok: true, duplicate: false, lead: created });
    }

    res.setHeader("Allow", "GET, POST");
    return res.status(405).json({ ok: false, error: "Method Not Allowed" });
  } catch (err: any) {
    console.error("API /api/leads error:", err);
    return res.status(500).json({ ok: false, error: err?.message || "Internal Server Error" });
  }
}
