import { useEffect, useMemo, useState } from "react";
import AppNav from "@/components/AppNav";
import type { GetServerSideProps } from "next";
import { getIronSession } from "iron-session";
import { sessionOptions, type SessionData } from "@/lib/session";
import { Role } from "@prisma/client";

type Lead = {
  id: string;
  publicId: string;
  sourceType: string;             // use string instead of narrow enum here
  company?: string | null;
  contactName?: string | null;
  email?: string | null;
  phoneE164?: string | null;
  serviceCode?: string | null;
  zip?: string | null;
  postalCode?: string | null;     // keep optional, may or may not exist in DB
  aiScore?: number | null;
  scoreFactors?: {
    reasons?: string[];
    sourceDetail?: string;
    notes?: string;
  };
  status?: string | null;
  createdAt: string;
};

export default function LeadsPage() {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

   // form state
  const [sourceDetail, setSourceDetail] = useState("");
  const [sourceType, setSourceType] = useState<"EMPLOYEE_REFERRAL" | "EXISTING_CUSTOMER" | "NEW_CUSTOMER" | "INBOUND_PHONE" | "INBOUND_EMAIL" | "WALK_IN" | "WEB_FORM" | "OTHER">("EXISTING_CUSTOMER");

  const [company, setCompany] = useState("");
  const [contactName, setContactName] = useState("");
  const [email, setEmail] = useState("");
  const [phoneE164, setPhoneE164] = useState("");
  const [serviceCode, setServiceCode] = useState("");

  // NEW address fields
  const [addressLine1, setAddressLine1] = useState("");
  const [addressLine2, setAddressLine2] = useState("");
  const [city, setCity] = useState("");
  const [state, setState] = useState("");
  const [postalCode, setPostalCode] = useState("");   // replaces “zip” in the UI
  const [country, setCountry] = useState("US");
  const [zip, setZip] = useState("");

  // NEW notes
  const [notes, setNotes] = useState("");


  async function load() {
    setLoading(true);
    try {
      const res = await fetch("/api/leads");
      const data = await res.json();
      setLeads(Array.isArray(data?.leads) ? data.leads : []);
    } catch (e) {
      console.error(e);
      setMsg("Failed to load leads.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setMsg(null);
    try {
            const body = {
        sourceType,
        sourceDetail,
        company: company || undefined,
        contactName: contactName || undefined,
        email: email || undefined,
        phoneE164: phoneE164 || undefined,
        website: undefined, // leave out unless you want to keep this input
        serviceCode: serviceCode || undefined,

        // NEW — address + notes
        addressLine1: addressLine1 || undefined,
        addressLine2: addressLine2 || undefined,
        city:         city || undefined,
        state:        state || undefined,
        postalCode:   postalCode || undefined,
        zip:          zip || undefined,
        country:      country || undefined,
        notes:        notes || undefined,
      };

      const res = await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || "Error creating lead");
      if (data?.duplicate) {
        setMsg(`Duplicate lead found (${data?.reason}).`);
      } else {
        setMsg("Lead created.");
      }
      // refresh list
      await load();
      // reset some fields
      setCompany("");
      setContactName("");
      setEmail("");
      setPhoneE164("");
      setServiceCode("");
      setAddressLine1("");
      setAddressLine2("");
      setCity("");
      setState("");
      setZip("");
      setNotes("");
    } catch (e: any) {
      console.error(e);
      setMsg(e?.message || "Failed to create lead.");
    } finally {
      setSubmitting(false);
    }
  }

  const sorted = useMemo(
    () =>
      [...leads].sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      ),
    [leads]
  );

  return (
    <div className="min-h-screen bg-gray-50">
    <AppNav />

      <main className="mx-auto max-w-6xl p-4 grid gap-6">
        {/* Create Lead */}
        <section className="bg-white rounded-xl shadow-sm border p-4">
          <h2 className="text-lg font-medium mb-3">Add a Lead</h2>
          {msg && (
            <div className="mb-3 rounded-md border text-sm px-3 py-2 bg-amber-50 border-amber-200 text-amber-900">
              {msg}
            </div>
          )}
          <form onSubmit={onSubmit} className="grid gap-3 md:grid-cols-6">
  {/* Source (internal/manual reasons) */}
  <div className="md:col-span-2">
    <label className="block text-sm text-gray-700">Source</label>
    <select
      className="mt-1 w-full rounded-md border px-3 py-2"
      value={sourceType}
      onChange={(e) =>
        setSourceType(e.target.value as any)
      }
    >
      <option value="MANUAL_NEW_CUSTOMER">New Customer (manual)</option>
      <option value="MANUAL_EXISTING_CUSTOMER">Existing Customer</option>
      <option value="MANUAL_EMPLOYEE_REFERRAL">Employee Referral</option>
      <option value="MANUAL_OTHER">Other (manual)</option>
    </select>
  </div>

  {/* Company / Contact */}
  <div className="md:col-span-2">
    <label className="block text-sm text-gray-700">Company</label>
    <input
      className="mt-1 w-full rounded-md border px-3 py-2"
      value={company}
      onChange={(e) => setCompany(e.target.value)}
      placeholder="Business name"
    />
  </div>
  <div className="md:col-span-2">
    <label className="block text-sm text-gray-700">Contact name</label>
    <input
      className="mt-1 w-full rounded-md border px-3 py-2"
      value={contactName}
      onChange={(e) => setContactName(e.target.value)}
      placeholder="Person to reach"
    />
  </div>

  {/* Email / Phone */}
  <div className="md:col-span-2">
    <label className="block text-sm text-gray-700">Email</label>
    <input
      type="email"
      className="mt-1 w-full rounded-md border px-3 py-2"
      value={email}
      onChange={(e) => setEmail(e.target.value)}
      placeholder="alex@example.com"
    />
  </div>
  <div className="md:col-span-2">
    <label className="block text-sm text-gray-700">Phone</label>
    <input
      className="mt-1 w-full rounded-md border px-3 py-2"
      value={phoneE164}
      onChange={(e) => setPhoneE164(e.target.value)}
      placeholder="+19705551234"
    />
  </div>

  {/* Address */}
  <div className="md:col-span-3">
    <label className="block text-sm text-gray-700">Address line 1</label>
    <input
      className="mt-1 w-full rounded-md border px-3 py-2"
      value={addressLine1}
      onChange={(e) => setAddressLine1(e.target.value)}
      placeholder="123 Main St"
    />
  </div>
  <div className="md:col-span-3">
    <label className="block text-sm text-gray-700">Address line 2</label>
    <input
      className="mt-1 w-full rounded-md border px-3 py-2"
      value={addressLine2}
      onChange={(e) => setAddressLine2(e.target.value)}
      placeholder="Suite / Unit (optional)"
    />
  </div>
  <div className="md:col-span-2">
    <label className="block text-sm text-gray-700">City</label>
    <input
      className="mt-1 w-full rounded-md border px-3 py-2"
      value={city}
      onChange={(e) => setCity(e.target.value)}
      placeholder="Greeley"
    />
  </div>
  <div className="md:col-span-2">
    <label className="block text-sm text-gray-700">State</label>
    <input
      className="mt-1 w-full rounded-md border px-3 py-2"
      value={state}
      onChange={(e) => setState(e.target.value)}
      placeholder="CO"
    />
  </div>
  <div className="md:col-span-2">
  <label className="block text-sm text-gray-700">Postal code</label>
  <input
    className="mt-1 w-full rounded-md border px-3 py-2"
    value={postalCode}
    onChange={(e) => setPostalCode(e.target.value)}
    placeholder="80631"
  />
</div>

<div className="md:col-span-2">
  <label className="block text-sm text-gray-700">Country</label>
  <input
    className="mt-1 w-full rounded-md border px-3 py-2"
    value={country}
    onChange={(e) => setCountry(e.target.value)}
    placeholder="US"
  />
</div>

{/* Source (manual-entry) */}
<div className="md:col-span-2">
  <label className="block text-sm text-gray-700">Source</label>
  <select
    className="mt-1 w-full rounded-md border px-3 py-2"
    value={sourceType}
    onChange={(e) =>
      setSourceType(
        e.target.value as
          | "EMPLOYEE_REFERRAL"
          | "EXISTING_CUSTOMER"
          | "NEW_CUSTOMER"
          | "INBOUND_PHONE"
          | "INBOUND_EMAIL"
          | "WALK_IN"
          | "WEB_FORM"
          | "OTHER"
      )
    }
  >
    <option value="EMPLOYEE_REFERRAL">Employee Referral</option>
    <option value="EXISTING_CUSTOMER">Existing Customer</option>
    <option value="NEW_CUSTOMER">New Customer</option>
    <option value="INBOUND_PHONE">Inbound Phone</option>
    <option value="INBOUND_EMAIL">Inbound Email</option>
    <option value="WALK_IN">Walk-in</option>
    <option value="WEB_FORM">Web Form</option>
    <option value="OTHER">Other (manual)</option>
  </select>
</div>

{/* Source details (optional) */}
<div className="md:col-span-4">
  <label className="block text-sm text-gray-700">Source details (optional)</label>
  <textarea
    className="mt-1 w-full rounded-md border px-3 py-2"
    rows={3}
    value={sourceDetail}
    onChange={(e) => setSourceDetail(e.target.value)}
    placeholder="e.g., referred by Alex (Technician), called main line, found us via HOA notice, etc."
  />
</div>

  {/* Notes */}
  <div className="md:col-span-6">
    <label className="block text-sm text-gray-700">Notes</label>
    <textarea
      className="mt-1 w-full rounded-md border px-3 py-2"
      rows={3}
      value={notes}
      onChange={(e) => setNotes(e.target.value)}
      placeholder="Context from the call, timing, special instructions…"
    />
  </div>

  {/* Submit */}
  <div className="md:col-span-6 flex items-end">
    <button
      disabled={submitting}
      className="inline-flex items-center rounded-md bg-blue-600 text-white px-4 py-2 font-medium hover:bg-blue-700 disabled:opacity-50"
    >
      {submitting ? "Saving..." : "Save Lead"}
    </button>
  </div>
</form>
        </section>

        {/* Leads Table */}
        <section className="bg-white rounded-xl shadow-sm border p-4">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-medium">Recent Leads</h2>
            <button
              onClick={load}
              className="text-sm rounded-md border px-3 py-1 hover:bg-gray-50"
            >
              Refresh
            </button>
          </div>

          {loading ? (
            <div className="text-sm text-gray-600">Loading…</div>
          ) : sorted.length === 0 ? (
            <div className="text-sm text-gray-600">No leads yet.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm">
                <thead className="text-left bg-gray-100">
                  <tr>
                    <th className="p-2">Public ID</th>
                    <th className="p-2">Source</th>
                    <th className="p-2">Source Detail</th>
                    <th className="p-2">Company</th>
                    <th className="p-2">Contact</th>
                    <th className="p-2">Email</th>
                    <th className="p-2">Phone</th>
                    <th className="p-2">Service</th>
                    <th className="p-2">Postal/ZIP</th>
                    <th className="p-2">Score</th>
                    <th className="p-2">Reasons</th>
                    <th className="p-2">Created</th>
                  </tr>
                </thead>
                <tbody>
                  {sorted.map((l) => {
                    // Use `zip` until `postalCode` is confirmed in schema
                    const displayPostal = l.postalCode ?? l.zip ?? "—";

                    return (
                      <tr key={l.id} className="border-t">
                        <td className="p-2 font-mono">{l.publicId}</td>
                        <td className="p-2">{l.sourceType}</td>
                        <td className="p-2">
                          {l.scoreFactors?.sourceDetail || "—"}
                        </td>
                        <td className="p-2">{l.company || "—"}</td>
                        <td className="p-2">{l.contactName || "—"}</td>
                        <td className="p-2">{l.email || "—"}</td>
                        <td className="p-2">{l.phoneE164 || "—"}</td>
                        <td className="p-2">{l.serviceCode || "—"}</td>
                        <td className="p-2">{displayPostal}</td>
                        <td className="p-2">{l.aiScore ?? "—"}</td>
                        <td className="p-2">
                          {(l.scoreFactors?.reasons || []).join(", ") || "—"}
                        </td>
                        <td className="p-2">
                          {new Date(l.createdAt).toLocaleString()}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </main>
    </div>
  );
}

export const getServerSideProps: GetServerSideProps = async ({ req, res }) => {
  // @ts-ignore – Next provides Node req/res on pages router
  const session = await getIronSession<SessionData>(req, res, sessionOptions);
  const u = session.user;

  // Anyone logged in can access /leads (OWNER, MANAGER, STAFF, PROVIDER, ACCOUNTANT)
  if (!u) {
    return { redirect: { destination: "/login", permanent: false } };
  }

  return { props: {} };
};
