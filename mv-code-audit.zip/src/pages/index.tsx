// src/pages/index.tsx
import type { GetServerSideProps } from "next";
import { getIronSession } from "iron-session";
import { sessionOptions, type SessionData } from "@/lib/session";

/**
 * Internal app home:
 * - If logged in -> send to /dashboard
 * - If logged out -> send to /login
 */
export const getServerSideProps: GetServerSideProps = async ({ req, res }) => {
  // @ts-ignore – Next provides Node req/res
  const session = await getIronSession<SessionData>(req, res, sessionOptions);
  const u = session.user;
  if (!u) {
    return { redirect: { destination: "/login", permanent: false } };
  }
  // already logged in → go straight to dashboard
  return { redirect: { destination: "/dashboard", permanent: false } };
};

// Render nothing because we always redirect
export default function HomeRedirect() {
  return null;
}
