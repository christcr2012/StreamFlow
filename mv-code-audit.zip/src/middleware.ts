import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

// We’ll only use SSR/API for final role checks;
// middleware just prevents totally anonymous access to /admin/* quickly.
export function middleware(req: NextRequest) {
  const url = req.nextUrl;
  const path = url.pathname;

  // Paths you want to protect from anonymous users
  const protectedPaths = [/^\/admin(\/|$)/, /^\/api\/admin(\/|$)/];

  const isProtected = protectedPaths.some((re) => re.test(path));
  if (!isProtected) return NextResponse.next();

  // Read cookie set by iron-session (name in session.ts)
  const hasSessionCookie = req.cookies.has("mv_session");
  if (!hasSessionCookie) {
    const loginUrl = new URL("/login", req.url);
    loginUrl.searchParams.set("next", path); // optional: return after login
    return NextResponse.redirect(loginUrl);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/admin/:path*", "/api/admin/:path*"],
};
