// src/lib/session.ts
import { SessionOptions } from "iron-session";
import type { Role } from "@prisma/client";

export const sessionOptions: SessionOptions = {
  password: process.env.IRON_SESSION_PASSWORD as string,
  cookieName: "mv_session",
  cookieOptions: {
    secure: process.env.NODE_ENV === "production",
  },
};

// Reuse Prisma's Role enum directly so MANAGER/ACCOUNTANT are allowed too.
export type SessionUser = { email: string; role: Role };
export type SessionData = { user?: SessionUser };

declare module "iron-session" {
  interface IronSessionData {
    user?: SessionUser;
  }
}
