import Link from 'next/link'
import { useRouter } from 'next/router'
import { useState, useMemo } from 'react'

function clsx(...xs: (string | false | null | undefined)[]) {
  return xs.filter(Boolean).join(' ')
}

export default function Header() {
  const { pathname } = useRouter()
  const [open, setOpen] = useState(false)
  const isActive = (href: string) =>
    href === '/' ? pathname === '/' : pathname === href || pathname.startsWith(href + '/')

  // close menu on route change
  useMemo(() => { setOpen(false); return undefined }, [pathname])

  return (
    <header className="sticky top-0 z-50 bg-white/85 backdrop-blur border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-6">
        {/* Top bar */}
        <div className="flex items-center justify-between py-3">
          {/* Brand */}
          <Link href="/" className="flex items-center gap-3">
            <img
              src="/logo.png"  // or /logo.svg
              alt="Mountain Vista Cleaning"
              width={96}
              height={96}
              className="h-96 w-96 object-contain"
            />
            <span className="text-2x1 sm:text-3x1 font-bold text-gray-900">
              Mountain Vista
            </span>
          </Link>

          {/* Desktop nav */}
          <nav className="hidden md:flex items-center gap-6 text-base">
            <Link
              href="/intake"
              className={clsx(
                'transition-colors',
                isActive('/intake') ? 'text-black font-semibold' : 'text-gray-700 hover:text-black'
              )}
            >
              Request
            </Link>
            <Link
              href="/admin"
              className={clsx(
                'transition-colors',
                isActive('/admin') ? 'text-black font-semibold' : 'text-gray-700 hover:text-black'
              )}
            >
              Admin
            </Link>

            {/* CTA (desktop) */}
            <Link
              href="/intake"
              className="ml-2 inline-flex items-center rounded-lg bg-black px-4 py-2 text-sm font-medium text-white hover:bg-gray-900"
            >
              Get a Quote
            </Link>
          </nav>

          {/* Mobile menu button */}
          <button
            className="md:hidden inline-flex items-center justify-center rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm text-gray-700"
            aria-label="Toggle menu"
            aria-expanded={open}
            onClick={() => setOpen(v => !v)}
          >
            {open ? (
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
              </svg>
            ) : (
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                <path d="M3 6h18M3 12h18M3 18h18" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
              </svg>
            )}
          </button>
        </div>

        {/* Mobile panel */}
        <div className={clsx('md:hidden overflow-hidden transition-all duration-200', open ? 'max-h-64 pb-3' : 'max-h-0')}>
          <nav className="flex flex-col gap-2 text-base">
            <Link
              href="/intake"
              className={clsx(
                'rounded-lg px-3 py-2',
                isActive('/intake') ? 'bg-gray-900 text-white' : 'text-gray-800 hover:bg-gray-100'
              )}
            >
              Request
            </Link>
            <Link
              href="/admin"
              className={clsx(
                'rounded-lg px-3 py-2',
                isActive('/admin') ? 'bg-gray-900 text-white' : 'text-gray-800 hover:bg-gray-100'
              )}
            >
              Admin
            </Link>

            {/* CTA (mobile) */}
            <Link
              href="/intake"
              className="mt-1 inline-flex items-center justify-center rounded-lg bg-black px-4 py-2 text-sm font-medium text-white hover:bg-gray-900"
            >
              Get a Quote
            </Link>
          </nav>
        </div>
      </div>
    </header>
  )
}
