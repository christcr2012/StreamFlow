// src/components/AppNav.tsx
import Link from "next/link";
import useSWR from "swr";

type WhoAmI = { user?: { email: string; role: "OWNER" | "MANAGER" | "STAFF" | "PROVIDER" | "ACCOUNTANT" } };
const fetcher = (url: string) => fetch(url).then((r) => r.json());

export default function AppNav() {
  const { data } = useSWR<WhoAmI>("/api/whoami", fetcher);
  const user = data?.user;

  return (
    <header className="sticky top-0 z-10 bg-white/80 backdrop-blur border-b">
      <div className="mx-auto max-w-7xl px-4 py-3 flex items-center justify-between">
        {/* Left side: App name */}
        <div className="flex items-center gap-3">
          <Link href="/" className="text-base font-semibold text-gray-900">Mountain&nbsp;Vista</Link>
        </div>

        {/* Right side: auth-aware links */}
        <nav className="flex items-center gap-3 text-sm">
          {user ? (
            <>
              <Link className="text-gray-800 hover:underline" href="/dashboard">Dashboard</Link>
              <Link className="text-gray-800 hover:underline" href="/leads">Leads</Link>
              {(user.role === "OWNER" || user.role === "STAFF" || user.role === "MANAGER") && (
                <Link className="text-gray-800 hover:underline" href="/admin">Admin</Link>
              )}
              <form action="/api/auth/logout" method="post">
                <button className="rounded-md border px-3 py-1 hover:bg-gray-50" type="submit">
                  Sign out
                </button>
              </form>
            </>
          ) : (
            <Link className="rounded-md bg-blue-600 text-white px-4 py-1.5 font-medium hover:bg-blue-700" href="/login">
              Sign in
            </Link>
          )}
        </nav>
      </div>
    </header>
  );
}
