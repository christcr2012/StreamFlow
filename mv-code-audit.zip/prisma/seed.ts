// prisma/seed.ts
import { PrismaClient, Role, LeadSource } from "@prisma/client";
import crypto from "node:crypto";

const prisma = new PrismaClient();

/** Small helper so our required identityHash is consistent */
function identityHash(input: { email?: string | null; phoneE164?: string | null; company?: string | null; name?: string | null }) {
  const norm = (s?: string | null) => (s ?? "").trim().toLowerCase();
  const key = [norm(input.email), norm(input.phoneE164), norm(input.company), norm(input.name)].filter(Boolean).join("|");
  return crypto.createHash("sha256").update(key).digest("hex").slice(0, 24);
}

async function main() {
  // ---- 0) Inputs (change these to real values for your client) ----
  const ORG_NAME = "Mountain Vista Cleaning Services, LLC";
  const OWNER_EMAIL = process.env.SEED_OWNER_EMAIL || "owner@mountain-vista.example";
  const STAFF_EMAIL = process.env.SEED_STAFF_EMAIL || "staff@mountain-vista.example";

  // ---- 1) Org ----
  // Not unique by name in schema, so we findFirst-or-create
  let org = await prisma.org.findFirst({ where: { name: ORG_NAME } });
  if (!org) {
    org = await prisma.org.create({
      data: {
        name: ORG_NAME,
        featureFlags: {},
      },
    });
    console.log("Created org:", org.name, org.id);
  } else {
    console.log("Org already exists:", org.name, org.id);
  }

  // ---- 2) Users ----
  // We’re using email-allowlist auth (no password), so just create users with roles.
  const owner = await prisma.user.upsert({
    where: { email: OWNER_EMAIL },
    update: { orgId: org.id, role: Role.OWNER, status: "active" },
    create: {
      orgId: org.id,
      email: OWNER_EMAIL,
      name: "Business Owner",
      role: Role.OWNER,
      status: "active",
    },
  });
  console.log("Owner user:", owner.email);

  const staff = await prisma.user.upsert({
    where: { email: STAFF_EMAIL },
    update: { orgId: org.id, role: Role.STAFF, status: "active" },
    create: {
      orgId: org.id,
      email: STAFF_EMAIL,
      name: "Team Member",
      role: Role.STAFF,
      status: "active",
    },
  });
  console.log("Staff user:", staff.email);

  // ---- 3) Demo leads (optional but helpful) ----
  // Keep these minimal—only fields your schema requires + a few you've been using.
  // You can delete this block later if you want a clean DB.
  const leadsInput = [
    {
      company: "Sterling Office Park",
      contactName: "Alex Carter",
      email: "alex@sterlingop.com",
      phoneE164: "+19705550101",
      website: "https://sterlingop.com",
      serviceCode: "janitorial",
      addressLine1: "123 Main St",
      addressLine2: null,
      city: "Greeley",
      state: "CO",
      zip: "80631",
      postalCode: null,
      country: "US",
      notes: "Evening cleaning, M/W/F.",
      sourceType: LeadSource.MANUAL_EXISTING_CUSTOMER,
    },
    {
      company: "High Plains Credit Union",
      contactName: "Brianna V",
      email: "brianna@hpcredit.org",
      phoneE164: "+19705550102",
      website: null,
      serviceCode: "floorcare",
      addressLine1: "45 Center Ave",
      addressLine2: "Suite 200",
      city: "Sterling",
      state: "CO",
      zip: "80751",
      postalCode: null,
      country: "US",
      notes: "Quarterly strip & wax.",
      sourceType: LeadSource.MANUAL_EMPLOYEE_REFERRAL,
    },
    {
      company: "Frontier Dental",
      contactName: "Dr. Lee",
      email: "office@frontierdental.co",
      phoneE164: "+19705550103",
      website: "https://frontierdental.co",
      serviceCode: "disinfection",
      addressLine1: "900 Health Way",
      addressLine2: null,
      city: "Fort Collins",
      state: "CO",
      zip: "80525",
      postalCode: null,
      country: "US",
      notes: "Clinic-grade protocol required.",
      sourceType: LeadSource.MANUAL_NEW_CUSTOMER,
    },
  ];

  for (const li of leadsInput) {
    const publicId = `LEAD_${Math.random().toString(36).slice(2, 8).toUpperCase()}`;
    const ih = identityHash({ email: li.email, phoneE164: li.phoneE164, company: li.company, name: li.contactName });

    const lead = await prisma.lead.create({
      data: {
        orgId: org.id,
        publicId,
        sourceType: li.sourceType,            // enum LeadSource in your schema
        identityHash: ih,                     // required
        company: li.company ?? null,
        contactName: li.contactName ?? null,
        email: li.email ?? null,
        phoneE164: li.phoneE164 ?? null,
        website: li.website ?? null,
        serviceCode: li.serviceCode ?? null,
        address: li.addressLine1 ? `${li.addressLine1}${li.addressLine2 ? ", " + li.addressLine2 : ""}` : null,
        addressLine1: li.addressLine1 ?? null,
        addressLine2: li.addressLine2 ?? null,
        city: li.city ?? null,
        state: li.state ?? null,
        zip: li.zip ?? null,
        postalCode: li.postalCode ?? null,
        country: li.country ?? null,
        enrichmentJson: {},                   // keep empty for now
        aiScore: 72,                          // simple non-zero sample so UI shows something
        scoreFactors: { reasons: ["Seeded sample lead"] },
        notes: li.notes ?? null,
        status: "new",
      },
      select: { id: true, publicId: true },
    });

    console.log("Seeded lead:", lead.publicId);
  }

  console.log("✅ Seed complete.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
