-- AlterTable
ALTER TABLE "public"."Lead" ADD COLUMN     "address1" TEXT,
ADD COLUMN     "address2" TEXT,
ADD COLUMN     "city" TEXT,
ADD COLUMN     "notes" TEXT,
ADD COLUMN     "sourceDetail" TEXT,
ADD COLUMN     "state" TEXT;
