-- AlterTable
ALTER TABLE "public"."Lead" ADD COLUMN     "postalCode" TEXT;
